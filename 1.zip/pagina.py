from flask import Flask, jsonify

app = Flask(__name__)

# Información sobre la aplicación
info_aplicacion = {
    "nombre": "accunti",
    "descripcion": "Esta aplicación te ayuda a gestionar tus inventarios de forma eficiente.",
    "funcionalidades": [
        "Seguimiento de productos",
        "Gestión de stock",
        "Informes de inventario"
    ]
}

@app.route('/')
def home():
    return jsonify({"message": "¡Bienvenido a la página web de mi aplicación! https://accunti1.000webhostapp.com/#"})

@app.route('/info', methods=['GET'])
def obtener_info():
    # Devolvemos la información sobre la aplicación
    return jsonify(info_aplicacion)

if __name__ == '__main__':
    app.run(debug=True)
