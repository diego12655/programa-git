import tkinter as tk
from tkinter import ttk, filedialog
from tkinter import messagebox
from PIL import Image, ImageTk
import mysql.connector

class Aplicacion:
    def __init__(self, root):
        self.usuarios = {"admin": {"contraseña": "0000"}}
        self.inventario = {}
        self.mensajes = {}
        self.proveedores = {}
        self.root = root
        self.root.title("ACCUNTI")
        self.root.geometry("1920x1080")
        self.root.configure(bg="light green")
        self.fondo_image = Image.open("fondo1.jpg")
        self.fondo_photo = ImageTk.PhotoImage(self.fondo_image)

        # Crea un Label para mostrar la imagen de fondo
        self.fondo_label = tk.Label(self.root, image=self.fondo_photo)
        self.fondo_label.place(x=0, y=0, relwidth=1, relheight=1)  # Coloca la imagen detrás de otros widgets

        # Crear paneles y configurar panel inicial
        self.login_panel = self.create_login_panel()
        self.app_panel = self.create_app_panel()
        self.current_panel = None
        self.mostrar_panel(self.login_panel)

    # Crear panel de inicio de sesión
    def create_login_panel(self):
        login_panel = tk.Frame(self.root, bg="#90EE90", padx=20, pady=20)
        tk.Label(login_panel, text="Correo Electrónico:", bg="#90EE90").grid(row=0, column=0)
        tk.Label(login_panel, text="Contraseña:", bg="#90EE90").grid(row=1, column=0)
        self.correo_entry = tk.Entry(login_panel)
        self.contraseña_entry = tk.Entry(login_panel, show="*")
        self.correo_entry.grid(row=0, column=1)
        self.contraseña_entry.grid(row=1, column=1)
        login_button = tk.Button(login_panel, text="Ingresar", command=self.login, bg="#2E8B57", width=10)
        login_button.grid(row=2, columnspan=2)
        registrar_button = tk.Button(login_panel, text="Registrar", command=self.mostrar_registro, bg="#2E8B57", width=10)
        registrar_button.grid(row=3, columnspan=2)
        return login_panel

    # Crear panel de registro
    def mostrar_registro(self):
        registro_panel = tk.Toplevel(self.root)
        registro_panel.title("Registro")
        registro_panel.geometry("300x200")
        registro_panel.configure(bg="#90EE90")
        tk.Label(registro_panel, text="Correo Electrónico:", bg="#90EE90").grid(row=0, column=0)
        tk.Label(registro_panel, text="Contraseña:", bg="#90EE90").grid(row=1, column=0)
        self.registro_correo_entry = tk.Entry(registro_panel)
        self.registro_contraseña_entry = tk.Entry(registro_panel, show="*")
        self.registro_correo_entry.grid(row=0, column=1)
        self.registro_contraseña_entry.grid(row=1, column=1)
        registro_button = tk.Button(registro_panel, text="Registrar", command=self.registrar_usuario, bg="#2E8B57", width=10)
        registro_button.grid(row=2, columnspan=2)

    # Crear panel de la aplicación
    def create_app_panel(self):
        app_panel = tk.Frame(self.root, bg="#90EE90")
        inventario_button = tk.Button(app_panel, text="Inventario", command=self.mostrar_inventario, bg="#2E8B57", width=15)
        inventario_button.grid(row=0, column=0, padx=10, pady=10)
        enviar_mensaje_button = tk.Button(app_panel, text="Enviar mensaje", command=self.mostrar_dialogo_enviar_mensaje, bg="#2E8B57", width=15)
        enviar_mensaje_button.grid(row=0, column=1, padx=10, pady=10)
        ver_mensajes_button = tk.Button(app_panel, text="Ver Mensajes", command=self.mostrar_mensajes, bg="#2E8B57", width=15)
        ver_mensajes_button.grid(row=0, column=2, padx=10, pady=10)
        añadir_usuario_button = tk.Button(app_panel, text="Añadir Usuario", command=self.mostrar_dialogo_añadir_usuario, bg="#2E8B57", width=15)
        añadir_usuario_button.grid(row=1, column=0, padx=10, pady=10)
        crear_producto_button = tk.Button(app_panel, text="Crear Producto", command=self.mostrar_dialogo_crear_producto, bg="#2E8B57", width=15)
        crear_producto_button.grid(row=1, column=1, padx=10, pady=10)
        borrar_producto_button = tk.Button(app_panel, text="Borrar Producto", command=self.borrar_producto, bg="#2E8B57", width=15)
        borrar_producto_button.grid(row=1, column=2, padx=10, pady=10)
        añadir_proveedor_button = tk.Button(app_panel, text="Añadir Proveedor", command=self.mostrar_dialogo_añadir_proveedor, bg="#2E8B57", width=15)
        añadir_proveedor_button.grid(row=2, column=0, padx=10, pady=10)
        ver_proveedores_button = tk.Button(app_panel, text="Ver Proveedores", command=self.mostrar_proveedores, bg="#2E8B57", width=15)
        ver_proveedores_button.grid(row=2, column=1, padx=10, pady=10)
        cambiar_logo_nombre_button = tk.Button(app_panel, text="Cambiar Logo y Nombre", command=self.cambiar_logo_y_nombre, bg="#2E8B57", width=20)
        cambiar_logo_nombre_button.grid(row=3, column=0, columnspan=2, padx=10, pady=10)
        cerrar_sesion_button = tk.Button(app_panel, text="Cerrar Sesión", command=self.cerrar_sesion, bg="#2E8B57", width=10)
        cerrar_sesion_button.grid(row=3, column=2, padx=10, pady=10, sticky="sw")
        return app_panel

    # Función para mostrar un panel específico
    def mostrar_panel(self, panel):
        if self.current_panel is not None:
            self.current_panel.pack_forget()
        self.current_panel = panel
        self.current_panel.pack()

    # Función para iniciar sesión
    def login(self):
        correo = self.correo_entry.get()
        contraseña = self.contraseña_entry.get()
        
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='accunti'
        )
        cursor = connection.cursor()
        try:
            query = "SELECT * FROM users WHERE email = %s AND password = %s"
            cursor.execute(query, (correo, contraseña))
            result = cursor.fetchone()
            if result:
                messagebox.showinfo("Acceso concedido", "Acceso concedido.")
                self.mostrar_panel(self.app_panel)
            else:
                messagebox.showerror("Acceso denegado", "Correo o contraseña incorrectos.")
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error al iniciar sesión: {err}")
        finally:
            cursor.close()
            connection.close()

    # Función para registrar un nuevo usuario
    def registrar_usuario(self):
        correo = self.registro_correo_entry.get()
        contraseña = self.registro_contraseña_entry.get()
        if not correo or not contraseña:
            messagebox.showerror("Error", "Por favor complete todos los campos.")
            return

        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='accunti'
        )
        cursor = connection.cursor()
        try:
            query = "INSERT INTO users (email, password) VALUES (%s, %s)"
            cursor.execute(query, (correo, contraseña))
            connection.commit()
            messagebox.showinfo("Registro exitoso", "Usuario registrado correctamente.")
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"Error al registrar el usuario: {err}")
        finally:
            cursor.close()
            connection.close()

    # Función para mostrar el inventario
    def mostrar_inventario(self):
        inventario_dialog = tk.Toplevel(self.root)
        inventario_dialog.title("Inventario")
        table = ttk.Treeview(inventario_dialog, columns=("Nombre", "Cantidad", "precio"), show="headings")
        table.heading("Nombre", text="Nombre")
        table.heading("Cantidad", text="Cantidad")
        table.heading("precio", text="precio")
        table.pack()
        for nombre, cantidad in self.inventario.items():
            table.insert("", "end", values=(nombre, cantidad))

    # Función para mostrar el diálogo de enviar mensaje
    def mostrar_dialogo_enviar_mensaje(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Enviar Mensaje")
        tk.Label(dialog, text="Destinatario:", bg="#90EE90").grid(row=0, column=0)
        self.destinatario_combobox = ttk.Combobox(dialog, values=list(self.usuarios.keys()))
        self.destinatario_combobox.grid(row=0, column=1)
        tk.Label(dialog, text="Mensaje:", bg="#90EE90").grid(row=1, column=0)
        self.mensaje_entry = tk.Entry(dialog)
        self.mensaje_entry.grid(row=1, column=1)
        enviar_button = tk.Button(dialog, text="Enviar", command=self.enviar_mensaje, bg="#2E8B57")
        enviar_button.grid(row=2, column=0, columnspan=2)

    # Función para enviar un mensaje
    def enviar_mensaje(self):
        destinatario = self.destinatario_combobox.get()
        mensaje = self.mensaje_entry.get()
        if not destinatario or not mensaje:
            messagebox.showerror("Error", "Por favor complete todos los campos.")
            return
        if destinatario not in self.mensajes:
            self.mensajes[destinatario] = []
        self.mensajes[destinatario].append(mensaje)
        messagebox.showinfo("Mensaje Enviado", "Mensaje enviado correctamente.")

    # Función para mostrar los mensajes
    def mostrar_mensajes(self):
        mensajes_dialog = tk.Toplevel(self.root)
        mensajes_dialog.title("Mensajes")
        table = ttk.Treeview(mensajes_dialog, columns=("Destinatario", "Mensaje"), show="headings")
        table.heading("Destinatario", text="Destinatario")
        table.heading("Mensaje", text="Mensaje")
        table.pack()
        for destinatario, mensajes in self.mensajes.items():
            for mensaje in mensajes:
                table.insert("", "end", values=(destinatario, mensaje))

    # Función para mostrar el diálogo de añadir usuario
    def mostrar_dialogo_añadir_usuario(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Añadir Usuario")
        tk.Label(dialog, text="Correo Electrónico:", bg="#90EE90").grid(row=0, column=0)
        tk.Label(dialog, text="Contraseña:", bg="#90EE90").grid(row=1, column=0)
        self.nuevo_correo_entry = tk.Entry(dialog)
        self.nueva_contraseña_entry = tk.Entry(dialog, show="*")
        self.nuevo_correo_entry.grid(row=0, column=1)
        self.nueva_contraseña_entry.grid(row=1, column=1)
        añadir_button = tk.Button(dialog, text="Añadir", command=self.añadir_usuario, bg="#2E8B57")
        añadir_button.grid(row=2, column=0, columnspan=2)

    # Función para añadir un usuario
    def añadir_usuario(self):
        correo = self.nuevo_correo_entry.get()
        contraseña = self.nueva_contraseña_entry.get()
        if not correo or not contraseña:
            messagebox.showerror("Error", "Por favor complete todos los campos.")
            return
        if correo in self.usuarios:
            messagebox.showerror("Error", "El usuario ya existe.")
            return
        self.usuarios[correo] = {"contraseña": contraseña}
        messagebox.showinfo("Usuario añadido", "Usuario añadido correctamente.")

    # Función para mostrar el diálogo de crear producto
    def mostrar_dialogo_crear_producto(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Crear Producto")
        tk.Label(dialog, text="Nombre del Producto:", bg="#90EE90").grid(row=0, column=0)
        tk.Label(dialog, text="Cantidad:", bg="#90EE90").grid(row=1, column=0)
        self.producto_nombre_entry = tk.Entry(dialog)
        self.producto_cantidad_entry = tk.Entry(dialog)
        self.producto_nombre_entry.grid(row=0, column=1)
        self.producto_cantidad_entry.grid(row=1, column=1)
        crear_button = tk.Button(dialog, text="Crear", command=self.crear_producto, bg="#2E8B57")
        crear_button.grid(row=2, column=0, columnspan=2)

    # Función para crear un producto
    def crear_producto(self):
        nombre = self.producto_nombre_entry.get()
        cantidad = self.producto_cantidad_entry.get()
        if not nombre or not cantidad:
            messagebox.showerror("Error", "Por favor complete todos los campos.")
            return
        self.inventario[nombre] = int(cantidad)
        messagebox.showinfo("Producto creado", "Producto creado correctamente.")

    # Función para borrar un producto
    def borrar_producto(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Borrar Producto")
        tk.Label(dialog, text="Nombre del Producto:", bg="#90EE90").grid(row=0, column=0)
        self.borrar_producto_nombre_entry = tk.Entry(dialog)
        self.borrar_producto_nombre_entry.grid(row=0, column=1)
        borrar_button = tk.Button(dialog, text="Borrar", command=self.borrar_producto_confirmar, bg="#2E8B57")
        borrar_button.grid(row=1, column=0, columnspan=2)

    # Función para confirmar el borrado de un producto
    def borrar_producto_confirmar(self):
        nombre = self.borrar_producto_nombre_entry.get()
        if nombre in self.inventario:
            del self.inventario[nombre]
            messagebox.showinfo("Producto borrado", "Producto borrado correctamente.")
        else:
            messagebox.showerror("Error", "El producto no existe.")

    # Función para mostrar el diálogo de añadir proveedor
    def mostrar_dialogo_añadir_proveedor(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Añadir Proveedor")
        tk.Label(dialog, text="Nombre del Proveedor:", bg="#90EE90").grid(row=0, column=0)
        tk.Label(dialog, text="Teléfono:", bg="#90EE90").grid(row=1, column=0)
        self.proveedor_nombre_entry = tk.Entry(dialog)
        self.proveedor_telefono_entry = tk.Entry(dialog)
        self.proveedor_nombre_entry.grid(row=0, column=1)
        self.proveedor_telefono_entry.grid(row=1, column=1)
        añadir_button = tk.Button(dialog, text="Añadir", command=self.añadir_proveedor, bg="#2E8B57")
        añadir_button.grid(row=2, column=0, columnspan=2)

    # Función para añadir un proveedor
    def añadir_proveedor(self):
        nombre = self.proveedor_nombre_entry.get()
        telefono = self.proveedor_telefono_entry.get()
        if not nombre or not telefono:
            messagebox.showerror("Error", "Por favor complete todos los campos.")
            return
        if nombre in self.proveedores:
            messagebox.showerror("Error", "El proveedor ya existe.")
            return
        self.proveedores[nombre] = telefono
        messagebox.showinfo("Proveedor añadido", "Proveedor añadido correctamente.")

    # Función para mostrar los proveedores
    def mostrar_proveedores(self):
        proveedores_dialog = tk.Toplevel(self.root)
        proveedores_dialog.title("Proveedores")
        table = ttk.Treeview(proveedores_dialog, columns=("Nombre", "Teléfono"), show="headings")
        table.heading("Nombre", text="Nombre")
        table.heading("Teléfono", text="Teléfono")
        table.pack()
        for nombre, telefono in self.proveedores.items():
            table.insert("", "end", values=(nombre, telefono))

    # Función para cambiar el logo y nombre
    def cambiar_logo_y_nombre(self):
        # Implementa la funcionalidad para cambiar el logo y nombre aquí
    
        cambiar_logo_nombre_panel = tk.Toplevel(self.root)
        cambiar_logo_nombre_panel.title("Cambiar Logo y Nombre")
        cambiar_logo_nombre_panel.geometry("300x200")
        cambiar_logo_nombre_panel.configure(bg="#90EE90")
        tk.Label(cambiar_logo_nombre_panel, text="Nombre:", bg="#90EE90").grid(row=0, column=0)
        self.nuevo_nombre_entry = tk.Entry(cambiar_logo_nombre_panel)
        self.nuevo_nombre_entry.grid(row=0, column=1)
        seleccionar_logo_button = tk.Button(cambiar_logo_nombre_panel, text="Seleccionar Logo", command=self.seleccionar_logo, bg="#2E8B57", width=15)
        seleccionar_logo_button.grid(row=1, column=0, padx=10, pady=10)
        aplicar_button = tk.Button(cambiar_logo_nombre_panel, text="Aplicar Cambios", command=self.aplicar_cambios, bg="#2E8B57", width=15)
        aplicar_button.grid(row=1, column=1, padx=10, pady=10)

    # Función para seleccionar el logo
    def seleccionar_logo(self):
        file_path = filedialog.askopenfilename(filetypes=[("Imagenes", "*.jpg;*.png")])
        if file_path:
            self.logo_path = file_path
            image = Image.open(file_path)
          
            self.logo_image = ImageTk.PhotoImage(image)
            self.logo_label.config(image=self.logo_image)

    # Función para aplicar cambios de logo y nombre
    def aplicar_cambios(self):
        nuevo_nombre = self.nuevo_nombre_entry.get()
        if nuevo_nombre:
            self.nombre_label.config(text=nuevo_nombre)
            self.nombre = nuevo_nombre
            self.guardar_cambios()
            messagebox.showinfo("Éxito", "Cambios aplicados exitosamente.")
        else:
            messagebox.showerror("Error", "Por favor, ingrese un nombre.")

    
    # Función para cerrar sesión
    def cerrar_sesion(self):
        self.mostrar_panel(self.login_panel)

def main():
    root = tk.Tk()
    app = Aplicacion(root)
    root.mainloop()

if __name__ == "__main__":
    main()