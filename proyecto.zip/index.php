<!DOCTYPE html>
<html lang="es">

<head>
    <!-- Metadatos -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACCUNTI - Inicio</title>

    <!-- Estilos -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        /* Estilos personalizados */
        body {
            background-color: #f8f9fa; /* Fondo gris claro */
            font-family: Arial, sans-serif;
            color: #343a40; /* Color de texto oscuro */
            margin-top: 50px; /* Espacio superior para evitar la superposición con la barra de navegación */
        }
        .navbar {
            background-color: #4CAF50; /* Verde */
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: white;
            font-weight: bold;
        }
        .navbar-brand img {
            width: 30px; /* Ajustar el tamaño del logo */
            margin-right: 10px; /* Espacio entre el logo y el texto */
        }
        .jumbotron {
            background-color: #4CAF50; /* Verde */
            color: white;
            padding: 100px 0; /* Aumentar el espacio interno para contenido centrado */
            margin-bottom: 0; /* Eliminar el margen inferior */
            text-align: center;
        }
        .jumbotron h1 {
            font-size: 3.5em; /* Tamaño grande para el título */
            margin-bottom: 30px; /* Espacio inferior */
        }
        .jumbotron p {
            font-size: 1.25em; /* Tamaño grande para el texto */
        }
        .section {
            padding: 50px 0; /* Espacio interior */
        }
        .section-heading {
            margin-bottom: 50px; /* Espacio inferior */
        }
        .section-heading h2 {
            font-size: 2.5em; /* Tamaño grande para el título */
            margin-bottom: 30px; /* Espacio inferior */
        }
        .section-content {
            font-size: 1.25em; /* Tamaño grande para el texto */
        }
        .footer {
            background-color: #343a40; /* Gris oscuro */
            color: white;
            padding: 30px 0;
            text-align: center;
        }
        .footer a {
            color: #9da0a3; /* Color de enlace */
        }
        .footer a:hover {
            color: white; /* Color de enlace al pasar el mouse */
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <!-- Logo y botón de navegación -->
            <a class="navbar-brand" href="#">
                <img src="logo.jpg" alt="ACCUNTI Logo">ACCUNTI
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Elementos de navegación -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Acerca de</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contacto">Contacto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#descargar">Descargar</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Fin Navbar -->

    <!-- Inicio -->
    <div class="jumbotron">
        <div class="container">
            <!-- Título y descripción -->
            <h1>¡Bienvenido a ACCUNTI!</h1>
            <img src="imagen.jpg" alt="Imagen 1" class="img-fluid rounded-circle mb-4">
            <p class="lead">ACCUNTI es una aplicación de gestión de inventarios diseñada para simplificar y optimizar tus procesos de control de inventario.</p>
            <!-- Botón "Leer Más" -->
            <a class="btn btn-primary btn-lg" href="#" role="button">Leer Más</a>
        </div>
    </div>
    <!-- Fin Inicio -->

    <!-- Acerca de -->
    <div id="about" class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Título de la sección -->
                    <div class="section-heading text-center">
                        <h2>Acerca de ACCUNTI</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!-- Imagen relacionada -->
                    <img src="imagen2.jpg" alt="Imagen 2" class="img-fluid mb-4">
                </div>
                
                <div class="col-md-6">
                    <!-- Contenido -->
                    <div class="section-content">
                        <h2>¿Qué es ACCUNTI?</h2>
                        <p>ACCUNTI es una aplicación de gestión de inventarios diseñada para ayudar a empresas de todos los tamaños a llevar un control eficiente de sus productos y existencias.</p>
                        <p>Nuestra plataforma ofrece características avanzadas y una interfaz fácil de usar para garantizar que tu empresa pueda administrar su inventario de manera efectiva.</p>
                        <h3>Misión</h3>
                        <p>Nuestra misión es proporcionar a las empresas una herramienta potente y fácil de usar para gestionar sus inventarios de manera eficiente, ahorrando tiempo y recursos.</p>
                        <h3>Visión</h3>
                        <p>Nuestra visión es ser líderes en la industria de la gestión de inventarios, brindando soluciones innovadoras y de calidad que impulsen el éxito de nuestros clientes.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Fin Acerca de -->

    <!-- Descargar -->
    <div id="descargar" class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Título de la sección -->
                    <div class="section-heading text-center">
                        <h2>Descargar ACCUNTI</h2>
                    </div>
                </div>
            </div>
           <!-- Botón de compartir en Facebook -->
<div class="fb-share-button" data-href="https://accunti1.000webhostapp.com/" data-layout="button_count" data-size="small"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Faccunti1.000webhostapp.com%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Compartir en facebook</a></div>

<!-- Botón de seguir en Facebook -->
<div class="fb-follow" data-href="https://www.facebook.com/profile.php?id=61556754897854&is_tour_completed=true" data-layout="button_count" data-size="small"><a target="_blank" href="https://www.facebook.com/profile.php?id=61556754897854&is_tour_completed=true" class="fb-xfbml-parse-ignore">Seguir en facebook</a></div>


            <div class="row">
                <div class="col-md-6 mx-auto text-center">
                    <!-- Descripción y botones de descarga -->
                    <p class="section-content">¡Descarga la aplicación ACCUNTI para administrar tu inventario de manera eficiente!</p>
                    <a href="https://drive.google.com/file/d/1370ck4pquc-K1dx-rPCVK9cA0SepBHxd/view?usp=drive_link" class="btn btn-primary btn-lg btn-block mb-3">Descargar para Windows</a>
                    <a href="#" class="btn btn-success btn-lg btn-block">Descargar para Android</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Fin Descargar -->

    <!-- Contacto -->
    <div id="contacto" class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Título de la sección -->
                    <div class="section-heading text-center">
                        <h2>Contacta con Nosotros</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <!-- Formulario de contacto -->
                    <form id="formulario" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                        <div class="form-group">
                            <input type="text" class="form-control" name="nombre" placeholder="Nombre" required>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="correo" placeholder="Correo Electrónico" required>
                        </div>
                        <div class="form-group">
                            <input type="tel" class="form-control" name="telefono" placeholder="Número de Teléfono (+57)" required>
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="mensaje" rows="5" placeholder="Mensaje" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Enviar</button>
                    </form>
                    <?php
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "accunti";

                        // Crear conexión
                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Verificar conexión
                        if ($conn->connect_error) {
                            die("Conexión fallida: " . $conn->connect_error);
                        }

                        // Obtener datos del formulario
                        $nombre = $_POST['nombre'];
                        $correo = $_POST['correo'];
                        $telefono = $_POST['telefono'];
                        $mensaje = $_POST['mensaje'];

                        // Preparar y ejecutar consulta
                        $stmt = $conn->prepare("INSERT INTO datos2 (nombre, email, numero, mensaje) VALUES (?, ?, ?, ?)");
                        $stmt->bind_param("ssss", $nombre, $correo, $telefono, $mensaje);

                        if ($stmt->execute()) {
                            echo "<div class='alert alert-success mt-4'>Datos guardados exitosamente</div>";
                        } else {
                            echo "<div class='alert alert-danger mt-4'>Error: " . $stmt->error . "</div>";
                        }

                        // Cerrar conexión
                        $stmt->close();
                        $conn->close();
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Fin Contacto -->

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Texto de pie de página -->
                    <p>© 2024 Todos los derechos reservados. 
                </div>
            </div>
        </div>
    </footer>
    <!-- Fin Footer -->

    <!-- Archivos Javascript -->
  
</body>

</html>
