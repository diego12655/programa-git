import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class formulario {
    public static void registerUser() {
        String email = JOptionPane.showInputDialog(null, "Ingrese su correo electrónico:");
        String password = JOptionPane.showInputDialog(null, "Ingrese su contraseña:");

        // Aquí puedes guardar los datos en una base de datos o en memoria
        // (simplemente mostraremos un mensaje por ahora)
        JOptionPane.showMessageDialog(null, "Usuario registrado exitosamente");
    }
}