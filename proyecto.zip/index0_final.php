
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "accunti";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['new-email']) && isset($_POST['new-password'])) {
        // Registro de usuario
        $email = $_POST['new-email'];
        $password = $_POST['new-password'];

        // Insertar datos en la tabla usuarios
        $sql = "INSERT INTO users (email, password) VALUES ('$email', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "Registro exitoso";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } elseif (isset($_POST['email']) && isset($_POST['password'])) {
        // Inicio de sesión
        $email = $_POST['email'];
        $password = $_POST['password'];

        // Verificar si los datos existen en la base de datos
        $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Inicio de sesión exitoso, redirigir al panel de la aplicación
            header("Location: " . $_SERVER['PHP_SELF'] . "?login=success");
            exit();
        } else {
            echo "Correo electrónico o contraseña incorrectos";
        }
    }
}

$conn->close();
?>




<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ACCUNTI</title>
<link rel="stylesheet" href="styles.css">
<script>
  function login() {
    document.getElementById('login-form').submit();
  }

  function showRegistrationPanel() {
    document.getElementById('login-panel').style.display = 'none';
    document.getElementById('registration-panel').style.display = 'block';
  }

  function closeAddUserDialog() {
    document.getElementById('registration-panel').style.display = 'none';
    document.getElementById('login-panel').style.display = 'block';
  }

  window.onload = function() {
    if (window.location.search.includes('login=success')) {
      document.getElementById('login-panel').style.display = 'none';
      document.getElementById('app-panel').style.display = 'block';
    }
  }
</script>
</head>
<body>
<style>
    body {
        background-image: url('fondo1.jpg');
        background-repeat: no-repeat;
        background-size: cover;
    }
</style>

<div id="login-panel" class="panel">
  <h2>Iniciar Sesión</h2>
  <form id="login-form" method="post" action="">
    <input type="text" name="email" placeholder="Correo electrónico" required>
    <input type="password" name="password" placeholder="Contraseña" required>
    <input type="submit" value="Ingresar">
  </form>
  <button onclick="showRegistrationPanel()">Registrarse</button>
</div>

<div id="app-panel" class="panel" style="display: none;">
  <h2>Panel de Aplicación</h2>
  <button onclick="showInventory()">Inventario</button>
  <button onclick="showSendMessageDialog()">Enviar Mensaje</button>
  <button onclick="showAddUserDialog()">Añadir Usuario</button>
  <button onclick="showCreateProductDialog()">Crear Producto</button>
  <button onclick="showDeleteProductDialog()">Borrar Producto</button>
  <button onclick="showAddProviderDialog()">Añadir Proveedor</button>
  <button onclick="showProviders()">Ver Proveedores</button>
  <button onclick="showMessages()">Ver mensajes</button>
  <button onclick="logout()">Cerrar Sesión</button>
</div>

<div id="registration-panel" class="dialog" style="display: none;">
  <h2>Registrarse</h2>
  <form method="post" action="">
    <input type="text" name="new-email" placeholder="Correo electrónico" required>
    <input type="password" name="new-password" placeholder="Contraseña" required>
    <input type="submit" value="Registrar">
  </form>
  <button type="button" onclick="closeAddUserDialog()">Cancelar</button>
</div>

<div id="send-message-dialog" class="dialog" style="display: none;">
  <h2>Enviar Mensaje</h2>
  <input type="text" id="recipient" placeholder="Destinatario">
  <textarea id="message" placeholder="Mensaje"></textarea>
  <button onclick="sendMessage()">Enviar</button>
  <button onclick="closeSendMessageDialog()">Cancelar</button>
</div>

<div id="add-user-dialog" class="dialog" style="display: none;">
  <h2>Añadir Usuario</h2>
  <input type="text" id="new-user-email" placeholder="Correo electrónico">
  <input type="password" id="new-user-password" placeholder="Contraseña">
  <button onclick="addUser()">Añadir</button>
  <button onclick="closeAddUserDialog()">Cancelar</button>
</div>

<div id="inventory-panel" class="panel hidden"></div>

<div id="add-provider-dialog" class="dialog" style="display: none;">
  <h2>Añadir Proveedor</h2>
  <input type="text" id="provider-name" placeholder="Nombre del proveedor">
  <input type="text" id="provider-phone" placeholder="Teléfono del proveedor">
  <button onclick="addProvider()">Añadir</button>
  <button onclick="closeAddProviderDialog()">Cancelar</button>
</div>

<script src="script.js"></script>
<a href="https://accunti1.000webhostapp.com/#">Visita nuestra Página web</a>

</body>
</html>
