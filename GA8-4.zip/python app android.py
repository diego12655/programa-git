from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.image import Image


# Simulación de datos de usuarios
users = {
    "admin@example.com": {
        "password": "0000"
    }
}


class LoginScreen(BoxLayout):
    def __init__(self, **kwargs):
        super(LoginScreen, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = [50, 20]

        # Agregar el logo de la aplicación
        self.add_widget(Image(source='LOGO.jpg', size_hint=(1, None), height=150))

        # Agregar el nombre de la aplicación
        app_name_label = Label(text="Accunti", font_size=30, size_hint=(1, None), height=50)
        app_name_label.bind(size=app_name_label.setter('text_size'))
        self.add_widget(app_name_label)

        # Agregar campos de entrada de correo electrónico y contraseña
        self.add_widget(Label(text="Correo electrónico:"))
        self.email_input = TextInput(multiline=False)
        self.add_widget(self.email_input)

        self.add_widget(Label(text="Contraseña:"))
        self.password_input = TextInput(multiline=False, password=True)
        self.add_widget(self.password_input)

        # Agregar botones de inicio de sesión y registro
        login_button = Button(text="Iniciar Sesión")
        login_button.bind(on_press=self.login)
        self.add_widget(login_button)

        register_button = Button(text="Registrarse")
        register_button.bind(on_press=self.show_register_popup)
        self.add_widget(register_button)

    def login(self, instance):
        email = self.email_input.text
        password = self.password_input.text

        if users.get(email) and users[email]["password"] == password:
            popup = Popup(title='Inicio de sesión exitoso',
                          content=Label(text='Inicio de sesión exitoso.'),
                          size_hint=(None, None), size=(400, 200))
            popup.open()
        else:
            popup = Popup(title='Error de inicio de sesión',
                          content=Label(text='Correo electrónico o contraseña incorrectos.'),
                          size_hint=(None, None), size=(400, 200))
            popup.open()

    def show_register_popup(self, instance):
        popup_content = BoxLayout(orientation='vertical', padding=10)
        popup_content.add_widget(Label(text="Nuevo Correo electrónico:"))
        self.new_email_input = TextInput(multiline=False)
        popup_content.add_widget(self.new_email_input)
        popup_content.add_widget(Label(text="Contraseña:"))
        self.new_password_input = TextInput(multiline=False, password=True)
        popup_content.add_widget(self.new_password_input)

        popup = Popup(title='Registro',
                      content=popup_content,
                      size_hint=(None, None), size=(400, 200))
        popup.open()


class MyApp(App):
    def build(self):
        return LoginScreen()


if __name__ == '__main__':
    MyApp().run()
